library(data.table)
library(MFSIS)
library(survival)
setwd("C:/Users/Administrator/Desktop/pycox-master/examples/TranSurv/2025.08.28/others/high data")
data=fread("16-Veer2002.csv",header=TRUE)
data=data[,-1];  ##序号删除
data[1:5,1:5]
dim(data)
X <- data[, 3:ncol(data)]
Y <- Surv(data$time, data$status)
A <- CSIS(X, Y);A
X=as.matrix(X)
Z=X[,A]
sdata=cbind(Y,Z);
head(sdata)
write.csv(sdata,"16-Veer2002_screening.csv",row.names = FALSE)